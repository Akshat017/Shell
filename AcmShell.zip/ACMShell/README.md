# ACMShell
A basic CLI supporting the following UNIX commands:
1. cd
2. help
3. history
4. exit
5. bg
and many other already built-in commands.
